/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-2

    Author: Fengting Wu # 301264494
    Date: Jan-22-2023

    Filename: project01-02.js
*/

//define variables for service name and service speed
const service1Name = "Basic";
const service2Name = "Express";
const service3Name = "Extreme";
const service4Name = "Ultimate";
const service1Speed = "0 Mbps";
const service2Speed = "100 Mbps";
const service3Speed = "500 Mbps";
const service4Speed = "1 Gig";
