/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-4

    Author: Fengting Wu
    Date:   Jan 29 2023

    Filename: project01-04.js
*/

//define variables for home and work addresses
const homeStreet = "1 Main St.";
const homeCity = "Sicilia";
const homeState = "MA";
const homeCode = "02103";
const workStreet = "15 Oak Ln.";
const workCity = "Central City";
const workState = "MA";
const workCode = "02104";
